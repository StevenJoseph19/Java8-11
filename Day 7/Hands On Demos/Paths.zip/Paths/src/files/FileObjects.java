package files;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Iterator;

public class FileObjects {

	public static void main(String[] args) {

		// try-catch block to handle exceptions
		try {
			// Create a new File instance by converting the given pathname string
			// into an abstract pathname
			File f = new File("C:\\workspace\\Java8and11\\Day2-HackerRankDemos\\src\\arrays\\minswaps2");

			// This filter will only include files ending with .txt
			FilenameFilter filter = new FilenameFilter() {

				@Override
				public boolean accept(File dir, String name) {

					return name.endsWith(".java");
				}
			};

			// Note that this time we are using a File class as an array,
			// instead of String.
			File[] files = f.listFiles(filter);

			// For each pathname in the pathname array
			for (File f1 : files) {
				// Get the names of the files by using the .getName() method
				System.out.println(f1.getName());
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}

	}

}
