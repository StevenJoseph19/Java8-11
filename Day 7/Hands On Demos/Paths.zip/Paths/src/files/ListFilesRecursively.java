package files;

import java.io.File;
import java.util.Iterator;

public class ListFilesRecursively {

	public void listFiles(String startDir) {
		File dir = new File(startDir);
		File[] files = dir.listFiles();

		if (files != null && files.length > 0)
			for (File file : files) {
				// Check if the file is a directory
				if (file.isDirectory()) {
					// We will not print the directory name, just use it as a new
					// starting point to list files from.
					startDir = file.getAbsolutePath();
				} else {
					// We can use .length() to get the file size
					System.out.println(file.getName() + " ( size in bytes : " + file.length() + ")");
				}

			}

	}

	public static void main(String[] args) {
		ListFilesRecursively test = new ListFilesRecursively();
		String startDir = "C:\\workspace\\Java8and11\\Day2-HackerRankDemos\\src\\arrays\\minswaps2";
		test.listFiles(startDir);
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
