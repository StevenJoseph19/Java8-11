Example code snippets for Java's CompletableFuture API

To build, Java 9 or greater is required. Just call the standard Maven build (e.g. `mvn verify`).
