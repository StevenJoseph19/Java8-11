package strings.validstring;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result2 {

	/*
	 * Complete the 'isValid' function below.
	 *
	 * The function is expected to return a STRING. The function accepts STRING s as
	 * parameter.
	 */

	public static String isValid(String s) {
		// Write your code here
		Map<Character, Integer> hm = new HashMap<>();

		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			hm.put(c, hm.getOrDefault(c, 0) + 1);
		}

		System.out.println(hm);

		if (hm.size() == 1)
			return "YES";

		int[] arr = new int[hm.size()];
		int index = 0;

		for (Map.Entry<Character, Integer> entry : hm.entrySet()) {
			arr[index++] = entry.getValue();
		}

		Arrays.sort(arr);

		System.out.println(Arrays.toString(arr));

		int begin = arr[0];
		int second = arr[1];
		int secondToLast = arr[arr.length - 2];
		int end = arr[arr.length - 1];

		// if first and last are same, then all frequencies are the same.
		if (begin == end)
			return "YES";

		// If first is 1 and all other characters have the same frequency.
		if (begin == 1 && second == end)
			return "YES";

		if (begin == second && second == secondToLast && secondToLast == (end - 1))
			return "YES";

		// else invalid string
		return "NO";

	}

}

public class Solution2 {
	public static void main(String[] args) throws IOException {
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(System.out));

		String s = bufferedReader.readLine();

		String result = Result2.isValid(s);

		bufferedWriter.write(result);
		bufferedWriter.newLine();

		bufferedReader.close();
		bufferedWriter.close();
	}
}
