package singlefile;

public class Hello {

	public static void main(String[] args) {

		String message = "Hello Java 11!";
		System.out.println(message);

	}

}
