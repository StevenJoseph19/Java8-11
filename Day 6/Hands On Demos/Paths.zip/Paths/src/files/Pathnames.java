package files;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Iterator;

public class Pathnames {

	public static void main(String[] args) {
		// Creates an array in which we will store the names of files and directories
		String[] pathnames;
		// Create a new File instance by converting the given pathname string
		// into an abstrat pathname
		File f = new File("C:\\workspace\\Java8and11\\Day2-HackerRankDemos\\src\\arrays\\minswaps2");

		// Populates the array with the names of files and directories
//		pathnames = f.list();

		// This filter will only include files ending with .txt
		FilenameFilter filter = new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {

				return name.endsWith(".txt");
			}
		};

		// This is how we apply the filter
		pathnames = f.list(filter);

		// For each pathname in the pathname array
		for (String pathname : pathnames) {
			// Print the names of files and directories
			System.out.println(pathname);
		}

	}

}
