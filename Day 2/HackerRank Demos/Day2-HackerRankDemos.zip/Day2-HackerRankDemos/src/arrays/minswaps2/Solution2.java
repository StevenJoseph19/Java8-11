package arrays.minswaps2;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class Solution2 {

	// Complete the minimumSwaps function below.
	static int minimumSwaps(int[] arr) {

		int n = arr.length;
		int loc[] = new int[n + 1];
		int i, count = 0;
		int curr, correctValue, indexCorrectValue;

		// get the position of all the values in the inital array.
		for (i = 0; i < n; i++)
			loc[arr[i]] = i;

		// match the inital array with the ascending sequence from 1 to array length
		for (i = 0; i < n; i++) {
			curr = arr[i];
			correctValue = i + 1;
			indexCorrectValue = loc[correctValue];
			if (curr != correctValue) {

				// swap the current value with the value that's should be here.
				arr[i] = correctValue;
				arr[indexCorrectValue] = curr;
				// update the value locations in the loc array.
				loc[correctValue] = i;
				loc[curr] = indexCorrectValue;

				// count the no. of swaps
				count++;
			}
		}

		return count;

	}

	private static final Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws IOException {
		BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(System.out));

		int n = scanner.nextInt();
		scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

		int[] arr = new int[n];

		String[] arrItems = scanner.nextLine().split(" ");
		scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

		for (int i = 0; i < n; i++) {
			int arrItem = Integer.parseInt(arrItems[i]);
			arr[i] = arrItem;
		}

		int res = minimumSwaps(arr);

		bufferedWriter.write(String.valueOf(res));
		bufferedWriter.newLine();

		bufferedWriter.close();

		scanner.close();
	}
}
