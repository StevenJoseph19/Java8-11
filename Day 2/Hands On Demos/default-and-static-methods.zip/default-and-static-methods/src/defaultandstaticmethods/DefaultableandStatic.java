package defaultandstaticmethods;

// A simple Java program to demonstrate default and static methods
// in Java 8.
interface DefaultStaticInterface {

	// abstract method
	public void square(int a);

	// default method
	default void display() {
		System.out.println("Default method executed!");
	}

	// static method
	static void show() {
		System.out.println("Static method executed!");
	}

}

public class DefaultableandStatic implements DefaultStaticInterface {
	@Override
	public void square(int a) {
		System.out.println(a * a);

	}

	public static void main(String[] args) {
		DefaultableandStatic d = new DefaultableandStatic();

		d.square(4);

		// Default method executed
		d.display();

		// Static method executed
		DefaultStaticInterface.show();

	}

}
